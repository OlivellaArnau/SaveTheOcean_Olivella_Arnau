﻿namespace SaveTheOcean_Olivella_Arnau
{
    partial class FirstMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnJugar = new Button();
            BtnSalir = new Button();
            lblSaveOcean = new Label();
            SuspendLayout();
            // 
            // BtnJugar
            // 
            BtnJugar.Font = new Font("Showcard Gothic", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BtnJugar.Location = new Point(138, 237);
            BtnJugar.Name = "BtnJugar";
            BtnJugar.Size = new Size(154, 49);
            BtnJugar.TabIndex = 0;
            BtnJugar.Text = "Jugar";
            BtnJugar.UseVisualStyleBackColor = true;
            BtnJugar.Click += BtnJugar_Click;
            // 
            // BtnSalir
            // 
            BtnSalir.Font = new Font("Showcard Gothic", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BtnSalir.Location = new Point(487, 237);
            BtnSalir.Name = "BtnSalir";
            BtnSalir.Size = new Size(154, 49);
            BtnSalir.TabIndex = 0;
            BtnSalir.Text = "Salir";
            BtnSalir.UseVisualStyleBackColor = true;
            BtnSalir.Click += BtnSalir_Click;
            // 
            // lblSaveOcean
            // 
            lblSaveOcean.AutoSize = true;
            lblSaveOcean.Font = new Font("Showcard Gothic", 30F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblSaveOcean.ForeColor = Color.CadetBlue;
            lblSaveOcean.Location = new Point(228, 91);
            lblSaveOcean.Name = "lblSaveOcean";
            lblSaveOcean.Size = new Size(349, 50);
            lblSaveOcean.TabIndex = 1;
            lblSaveOcean.Text = "Save The Ocean";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblSaveOcean);
            Controls.Add(BtnSalir);
            Controls.Add(BtnJugar);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnJugar;
        private Button BtnSalir;
        private Label lblSaveOcean;
    }
}
