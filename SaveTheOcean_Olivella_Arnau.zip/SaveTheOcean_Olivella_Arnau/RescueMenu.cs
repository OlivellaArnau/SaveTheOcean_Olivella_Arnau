﻿using NLog.Targets.Wrappers;
using Npgsql;
using SaveTheOcean_Olivella_Arnau.Persistence.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaveTheOcean_Olivella_Arnau
{
    public partial class RescueMenu : Form
    {
        private string PlayerName;
        public RescueMenu(string export)
        {

            InitializeComponent();
            PlayerName = export;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void RescueMenu_Load(object sender, EventArgs e)
        {
            AddUserMenu addUserMenu = new AddUserMenu();
            lblwelcome.Text = "Welcome " + PlayerName + "\nNecessitem la teva ajuda per rescatar a un animal!";
            lblRES.Text = RandomRescue();
            lblDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            lblGA.Text = RandomGA();
            using (NpgsqlConnection connection = new NpgsqlConnection(NpgsqlUtils.OpenConnection()))
            {
                string query = "SELECT * FROM Animal ORDER BY RANDOM() LIMIT 1";
                NpgsqlCommand command = new NpgsqlCommand(query, connection);
                connection.Open();
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    string name = reader.GetString(reader.GetOrdinal("Name"));
                    string location = reader.GetString(reader.GetOrdinal("Location"));
                    string family = reader.GetString(reader.GetOrdinal("Family"));
                    string superFamily = reader.GetString(reader.GetOrdinal("Family"));
                    string species = reader.GetString(reader.GetOrdinal("Species"));
                    double weight = reader.GetDouble(reader.GetOrdinal("Weight"));

                    lblName.Text = name;
                    lblLocation.Text = location;
                    lblSuperFitxa.Text = superFamily;
                    lblSuperRescat.Text = family;
                    lblSpecie.Text = species;
                    lblWeight.Text = weight.ToString();
                }
            }

        }
        private string RandomRescue()
        {
            Random random = new Random();
            int num = random.Next(000, 999);
            return num.ToString();
        }
        private string RandomGA()
        {
            Random random = new Random();
            int num = random.Next(1, 100);
            return num.ToString();
        }
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            {
                string path = "Player.xml";
                if (lblSuperRescat.Text == "Au Marina")
                {

                    int GA = int.Parse(lblGA.Text);
                    int x = 5;
                    int GAResultat = (GA - x) / 5;
                    if (GAResultat <= 30)
                    {
                        MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. L’exemplar està recuperat i pot tornar al seu hàbitat. La teva experiència ha augmentat en +50XP.\r\nFins el proper rescat!\r\n");
                    }
                    else
                    {
                        MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. No ha estat prou efectiu i cal traslladar l’exemplar al centre. La teva experiència s’ha reduït en -20XP.");

                    }
                }
                else if (lblSuperRescat.Text == "Tortuga marina")
                {
                    int GA = int.Parse(lblGA.Text);
                    int x = 15;
                    int GAResultat = (2 * GA + 3) - ((GA - 20) * 2) - x;
                    if (GAResultat <= 30)
                    {
                        MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. L’exemplar està recuperat i pot tornar al seu hàbitat. La teva experiència ha augmentat en +50XP.\r\nFins el proper rescat!\r\n");
                    }
                    else
                    {
                        MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. No ha estat prou efectiu i cal traslladar l’exemplar al centre. La teva experiència s’ha reduït en -20XP.");

                    }
                }
                else if (lblSuperRescat.Text == "Cetaci")
                {
                    int GA = int.Parse(lblGA.Text);
                    int x = 50;
                    int GAResultat = GA - (GA / 5) - x;
                    if (GAResultat <= 30)
                    {
                        MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. L’exemplar està recuperat i pot tornar al seu hàbitat. La teva experiència ha augmentat en +50XP.\r\nFins el proper rescat!\r\n");
                    }
                    else
                    {
                        MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. No ha estat prou efectiu i cal traslladar l’exemplar al centre. La teva experiència s’ha reduït en -20XP.");

                    }
                }
                else
                {
                    int GA = int.Parse(lblGA.Text);
                    int x = 5;
                    int GAResultat = (GA - x) / 5;
                    if (GAResultat <= 30)
                    {
                        MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. L’exemplar està recuperat i pot tornar al seu hàbitat. La teva experiència ha augmentat en +50XP.\r\nFins el proper rescat!\r\n");
                    }
                    else
                    {
                        MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. No ha estat prou efectiu i cal traslladar l’exemplar al centre. La teva experiència s’ha reduït en -20XP.");

                    }
                }
                Close();
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void btnCRAM_Click(object sender, EventArgs e)
        {
            string path = "Player.xml";

            if (lblSuperRescat.Text == "Au Marina")
            {

                int GA = int.Parse(lblGA.Text);
                int x = 0;
                int GAResultat = (GA - x) / 5;
                if (GAResultat <= 30)
                {
                    MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. L’exemplar està recuperat i pot tornar al seu hàbitat. La teva experiència ha augmentat en +50XP.\r\nFins el proper rescat!\r\n");

                }
                else
                {
                    MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. No ha estat prou efectiu i cal traslladar l’exemplar al centre. La teva experiència s’ha reduït en -20XP.");
                }
            }
            else if (lblSuperRescat.Text == "Tortuga marina")
            {
                int GA = int.Parse(lblGA.Text);
                int x = 15;
                int GAResultat = (2 * GA + 3) - ((GA - 20) * 2) - x;
                if (GAResultat <= 30)
                {
                    MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. L’exemplar està recuperat i pot tornar al seu hàbitat. La teva experiència ha augmentat en +50XP.\r\nFins el proper rescat!\r\n");
                }
                else
                {
                    MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. No ha estat prou efectiu i cal traslladar l’exemplar al centre. La teva experiència s’ha reduït en -20XP.");
                }
            }
            else if (lblSuperRescat.Text == "Cetaci")
            {
                int GA = int.Parse(lblGA.Text);
                int x = 0;
                int GAResultat = GA - (GA / 5) - x;
                if (GAResultat <= 30)
                {
                    MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. L’exemplar està recuperat i pot tornar al seu hàbitat. La teva experiència ha augmentat en +50XP.\r\nFins el proper rescat!\r\n");
                }
                else
                {
                    MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. No ha estat prou efectiu i cal traslladar l’exemplar al centre. La teva experiència s’ha reduït en -20XP.");

                }
            }
            else
            {
                int GA = int.Parse(lblGA.Text);
                int x = 5;
                int GAResultat = (GA - x) / 5;
                if (GAResultat <= 30)
                {
                    MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. L’exemplar està recuperat i pot tornar al seu hàbitat. La teva experiència ha augmentat en +50XP.\r\nFins el proper rescat!\r\n");
                }
                else
                {
                    MessageBox.Show($"El tractament aplicat ha reduït el GA fins al {GAResultat}%. No ha estat prou efectiu i cal traslladar l’exemplar al centre. La teva experiència s’ha reduït en -20XP.");

                }
            }
            Close();
        }
    }
}
