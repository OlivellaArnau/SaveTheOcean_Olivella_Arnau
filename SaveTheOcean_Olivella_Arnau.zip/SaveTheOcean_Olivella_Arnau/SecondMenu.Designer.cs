﻿namespace SaveTheOcean_Olivella_Arnau
{
    partial class SecondMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblSaveOcean = new Label();
            BtnJugar2 = new Button();
            BtnAddAnimal = new Button();
            SuspendLayout();
            // 
            // lblSaveOcean
            // 
            lblSaveOcean.AutoSize = true;
            lblSaveOcean.Font = new Font("Showcard Gothic", 30F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblSaveOcean.ForeColor = Color.CadetBlue;
            lblSaveOcean.Location = new Point(212, 99);
            lblSaveOcean.Name = "lblSaveOcean";
            lblSaveOcean.Size = new Size(349, 50);
            lblSaveOcean.TabIndex = 2;
            lblSaveOcean.Text = "Save The Ocean";
            // 
            // BtnJugar2
            // 
            BtnJugar2.Font = new Font("Showcard Gothic", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BtnJugar2.Location = new Point(129, 253);
            BtnJugar2.Name = "BtnJugar2";
            BtnJugar2.Size = new Size(154, 49);
            BtnJugar2.TabIndex = 3;
            BtnJugar2.Text = "Jugar";
            BtnJugar2.UseVisualStyleBackColor = true;
            BtnJugar2.Click += BtnJugar2_Click;
            // 
            // BtnAddAnimal
            // 
            BtnAddAnimal.Font = new Font("Showcard Gothic", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BtnAddAnimal.Location = new Point(479, 253);
            BtnAddAnimal.Name = "BtnAddAnimal";
            BtnAddAnimal.Size = new Size(154, 49);
            BtnAddAnimal.TabIndex = 4;
            BtnAddAnimal.Text = "Añadir Animal";
            BtnAddAnimal.UseVisualStyleBackColor = true;
            BtnAddAnimal.Click += BtnAddAnimal_Click;
            // 
            // SecondMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnAddAnimal);
            Controls.Add(BtnJugar2);
            Controls.Add(lblSaveOcean);
            Name = "SecondMenu";
            Text = "Menu2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblSaveOcean;
        private Button BtnJugar2;
        private Button BtnAddAnimal;
    }
}