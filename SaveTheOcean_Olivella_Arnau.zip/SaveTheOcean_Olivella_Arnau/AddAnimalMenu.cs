﻿using SaveTheOcean_Olivella_Arnau.Persistence.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SaveTheOcean_Olivella_Arnau.DTO;
using SaveTheOcean_Olivella_Arnau.Persistence.Utils;
using SaveTheOcean_Olivella_Arnau.Persistence.Mapping;
using System.Text.RegularExpressions;
using Npgsql;

namespace SaveTheOcean_Olivella_Arnau
{
    public partial class AddAnimalMenu : Form
    {
        public AddAnimalMenu()
        {
            InitializeComponent();
        }
        private void BtnAddAnimal_Click(object sender, EventArgs e)
        {
            string Name = txtBoxName.Text;
            string Location = txtBoxLocation.Text;
            string Family = txtBoxFamily.Text;
            string Species = txtBoxSpecies.Text;
            double Weight = Convert.ToDouble(txtBoxWeight.Text);
            IAnimalDAO animalDAO = new AnimalDAO(NpgsqlUtils.OpenConnection());
            AnimalDTO animal = new AnimalDTO
            {
                Date = DateTime.Now,
                Name = Name,
                Family = Family,
                Location = Location,
                Species = Species,
                Weight = Weight

            };
            
                animalDAO.AddAnimal(animal);
                MessageBox.Show("Animal added successfully");
                Hide();
                SecondMenu secondMenu = new SecondMenu();
                secondMenu.ShowDialog();

        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
