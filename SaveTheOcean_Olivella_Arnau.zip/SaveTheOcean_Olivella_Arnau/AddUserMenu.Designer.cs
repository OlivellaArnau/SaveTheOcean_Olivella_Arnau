﻿namespace SaveTheOcean_Olivella_Arnau
{
    partial class AddUserMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            txtBoxName = new TextBox();
            cBoxProfesion = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(196, 122);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "Guardar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtBoxName
            // 
            txtBoxName.Location = new Point(171, 29);
            txtBoxName.Name = "txtBoxName";
            txtBoxName.Size = new Size(100, 23);
            txtBoxName.TabIndex = 1;
            // 
            // cBoxProfesion
            // 
            cBoxProfesion.FormattingEnabled = true;
            cBoxProfesion.Items.AddRange(new object[] { "Veterinario", "Tecnico" });
            cBoxProfesion.Location = new Point(171, 75);
            cBoxProfesion.Name = "cBoxProfesion";
            cBoxProfesion.Size = new Size(100, 23);
            cBoxProfesion.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 37);
            label1.Name = "label1";
            label1.Size = new Size(113, 15);
            label1.TabIndex = 3;
            label1.Text = "Nombre de Usuario:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(28, 78);
            label2.Name = "label2";
            label2.Size = new Size(60, 15);
            label2.TabIndex = 4;
            label2.Text = "Profesion:";
            // 
            // AddUserMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(301, 164);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cBoxProfesion);
            Controls.Add(txtBoxName);
            Controls.Add(button1);
            Name = "AddUserMenu";
            Text = "AddUserMenu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox txtBoxName;
        private ComboBox cBoxProfesion;
        private Label label1;
        private Label label2;
    }
}