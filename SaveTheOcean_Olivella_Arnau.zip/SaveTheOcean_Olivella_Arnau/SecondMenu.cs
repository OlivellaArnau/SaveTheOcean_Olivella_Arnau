﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaveTheOcean_Olivella_Arnau
{
    public partial class SecondMenu : Form
    {
        public SecondMenu()
        {
            InitializeComponent();
        }

        private void BtnAddAnimal_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddAnimalMenu addAnimal = new AddAnimalMenu();
            addAnimal.ShowDialog();
            this.Close();

        }

        private void BtnJugar2_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddUserMenu addUser = new AddUserMenu();
            addUser.ShowDialog();
            this.Close();
        }
    }
}
