﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using SaveTheOcean_Olivella_Arnau.DTO;

namespace SaveTheOcean_Olivella_Arnau
{
    public class XMLHelper
    {
        public static void CreateXMLFile(PlayerDTO player, string filePath)
        {
            if (File.Exists(filePath))
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(filePath);

                
                if (PlayerExists(xmlDoc, player))
                {
                    return;
                }
            }
            else
            {
                CreateInitialXMLFile(filePath);
            }
            AddPlayerToXML(player, filePath);
        }

        private static void CreateInitialXMLFile(string filePath)
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlElement playersListElement = xmlDoc.CreateElement("PlayersList");
                xmlDoc.AppendChild(playersListElement);
                xmlDoc.Save(filePath);
                Console.WriteLine("Archivo XML creado correctamente.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al crear el archivo XML: {ex.Message}");
            }
        }

        private static bool PlayerExists(XmlDocument xmlDoc, PlayerDTO player)
        {
            XmlNodeList playerNodes = xmlDoc.SelectNodes("//Player");

            foreach (XmlNode playerNode in playerNodes)
            {
                string playerName = playerNode.SelectSingleNode("Name").InnerText;
                string playerRol = playerNode.SelectSingleNode("Rol").InnerText;


                if (playerName == player.Name && playerRol == player.Profesion)
                {
                    xmlDoc.Save("Player.xml");
                    return true;
                }
            }

            return false;
        }

        private static void AddPlayerToXML(PlayerDTO player, string filePath)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(filePath);

            XmlElement playersListElement = xmlDoc.DocumentElement;
            AddPlayerNode(xmlDoc, playersListElement, player);

            xmlDoc.Save(filePath);
        }

        private static void AddPlayerNode(XmlDocument xmlDoc, XmlElement parentElement, PlayerDTO player)
        {
            XmlElement playerElement = xmlDoc.CreateElement("Player");
            parentElement.AppendChild(playerElement);

            AddChildElement(xmlDoc, playerElement, "Name", player.Name);
            AddChildElement(xmlDoc, playerElement, "Rol", player.Profesion);
            AddChildElement(xmlDoc, playerElement, "Xp", player.XP.ToString());
        }

        private static void AddChildElement(XmlDocument xmlDoc, XmlElement parentElement, string elementName, string value)
        {
            XmlElement childElement = xmlDoc.CreateElement(elementName);
            childElement.InnerText = value;
            parentElement.AppendChild(childElement);
        }
    }
}
