﻿namespace SaveTheOcean_Olivella_Arnau
{
    partial class RescueMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSalvar = new Button();
            btnCRAM = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            lblwelcome = new Label();
            lblLocation = new Label();
            lblGA = new Label();
            lblSuperRescat = new Label();
            lblDate = new Label();
            lblRES = new Label();
            lblWeight = new Label();
            lblSpecie = new Label();
            lblSuperFitxa = new Label();
            lblName = new Label();
            SuspendLayout();
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(176, 386);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(112, 23);
            btnSalvar.TabIndex = 0;
            btnSalvar.Text = "Salvar Aquí";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // btnCRAM
            // 
            btnCRAM.Location = new Point(489, 386);
            btnCRAM.Name = "btnCRAM";
            btnCRAM.Size = new Size(112, 23);
            btnCRAM.TabIndex = 1;
            btnCRAM.Text = "Portar al CRAM";
            btnCRAM.UseVisualStyleBackColor = true;
            btnCRAM.Click += btnCRAM_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 98);
            label1.Name = "label1";
            label1.Size = new Size(32, 15);
            label1.TabIndex = 2;
            label1.Text = "Fitxa";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(31, 227);
            label2.Name = "label2";
            label2.Size = new Size(41, 15);
            label2.TabIndex = 3;
            label2.Text = "Rescat";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(47, 146);
            label3.Name = "label3";
            label3.Size = new Size(34, 15);
            label3.TabIndex = 4;
            label3.Text = "Nom";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(176, 146);
            label4.Name = "label4";
            label4.Size = new Size(73, 15);
            label4.TabIndex = 5;
            label4.Text = "Superfamilia";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(302, 146);
            label5.Name = "label5";
            label5.Size = new Size(46, 15);
            label5.TabIndex = 6;
            label5.Text = "Especie";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(415, 146);
            label6.Name = "label6";
            label6.Size = new Size(25, 15);
            label6.TabIndex = 7;
            label6.Text = "Pes";
            label6.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(47, 256);
            label7.Name = "label7";
            label7.Size = new Size(26, 15);
            label7.TabIndex = 12;
            label7.Text = "RES";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(176, 256);
            label8.Name = "label8";
            label8.Size = new Size(31, 15);
            label8.TabIndex = 13;
            label8.Text = "Data";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(302, 256);
            label9.Name = "label9";
            label9.Size = new Size(73, 15);
            label9.TabIndex = 14;
            label9.Text = "Superfamilia";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(415, 256);
            label10.Name = "label10";
            label10.Size = new Size(23, 15);
            label10.TabIndex = 15;
            label10.Text = "GA";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(535, 256);
            label11.Name = "label11";
            label11.Size = new Size(66, 15);
            label11.TabIndex = 16;
            label11.Text = "Locaització";
            // 
            // lblwelcome
            // 
            lblwelcome.AutoSize = true;
            lblwelcome.Location = new Point(31, 44);
            lblwelcome.Name = "lblwelcome";
            lblwelcome.Size = new Size(10, 15);
            lblwelcome.TabIndex = 22;
            lblwelcome.Text = " ";
            lblwelcome.Click += label12_Click;
            // 
            // lblLocation
            // 
            lblLocation.AutoSize = true;
            lblLocation.Location = new Point(535, 291);
            lblLocation.Name = "lblLocation";
            lblLocation.Size = new Size(10, 15);
            lblLocation.TabIndex = 31;
            lblLocation.Text = " ";
            // 
            // lblGA
            // 
            lblGA.AutoSize = true;
            lblGA.Location = new Point(415, 291);
            lblGA.Name = "lblGA";
            lblGA.Size = new Size(10, 15);
            lblGA.TabIndex = 30;
            lblGA.Text = " ";
            // 
            // lblSuperRescat
            // 
            lblSuperRescat.AutoSize = true;
            lblSuperRescat.Location = new Point(302, 291);
            lblSuperRescat.Name = "lblSuperRescat";
            lblSuperRescat.Size = new Size(10, 15);
            lblSuperRescat.TabIndex = 29;
            lblSuperRescat.Text = " ";
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Location = new Point(176, 291);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(10, 15);
            lblDate.TabIndex = 28;
            lblDate.Text = " ";
            // 
            // lblRES
            // 
            lblRES.AutoSize = true;
            lblRES.Location = new Point(47, 291);
            lblRES.Name = "lblRES";
            lblRES.Size = new Size(10, 15);
            lblRES.TabIndex = 27;
            lblRES.Text = " ";
            // 
            // lblWeight
            // 
            lblWeight.AutoSize = true;
            lblWeight.Location = new Point(415, 181);
            lblWeight.Name = "lblWeight";
            lblWeight.Size = new Size(10, 15);
            lblWeight.TabIndex = 26;
            lblWeight.Text = " ";
            // 
            // lblSpecie
            // 
            lblSpecie.AutoSize = true;
            lblSpecie.Location = new Point(302, 181);
            lblSpecie.Name = "lblSpecie";
            lblSpecie.Size = new Size(10, 15);
            lblSpecie.TabIndex = 25;
            lblSpecie.Text = " ";
            // 
            // lblSuperFitxa
            // 
            lblSuperFitxa.AutoSize = true;
            lblSuperFitxa.Location = new Point(176, 181);
            lblSuperFitxa.Name = "lblSuperFitxa";
            lblSuperFitxa.Size = new Size(10, 15);
            lblSuperFitxa.TabIndex = 24;
            lblSuperFitxa.Text = " ";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(47, 181);
            lblName.Name = "lblName";
            lblName.Size = new Size(10, 15);
            lblName.TabIndex = 23;
            lblName.Text = " ";
            // 
            // RescueMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblLocation);
            Controls.Add(lblGA);
            Controls.Add(lblSuperRescat);
            Controls.Add(lblDate);
            Controls.Add(lblRES);
            Controls.Add(lblWeight);
            Controls.Add(lblSpecie);
            Controls.Add(lblSuperFitxa);
            Controls.Add(lblName);
            Controls.Add(lblwelcome);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnCRAM);
            Controls.Add(btnSalvar);
            Name = "RescueMenu";
            Text = "RescueMenu";
            Load += RescueMenu_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSalvar;
        private Button btnCRAM;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label lblwelcome;
        private Label lblLocation;
        private Label lblGA;
        private Label lblSuperRescat;
        private Label lblDate;
        private Label lblRES;
        private Label lblWeight;
        private Label lblSpecie;
        private Label lblSuperFitxa;
        private Label lblName;
    }
}