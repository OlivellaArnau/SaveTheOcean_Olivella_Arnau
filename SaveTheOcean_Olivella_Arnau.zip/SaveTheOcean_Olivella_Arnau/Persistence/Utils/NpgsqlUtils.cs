﻿using SaveTheOcean_Olivella_Arnau.DTO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using Microsoft.Extensions.Configuration;
using SaveTheOcean_Olivella_Arnau.Persistence.Utils;


namespace SaveTheOcean_Olivella_Arnau.Persistence.Utils
{
    public class NpgsqlUtils
    {
        public static string OpenConnection()
        {
            IConfiguration config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();

            return config.GetConnectionString("MyPostgresConn");
        }

        public static AnimalDTO GetAnimal(NpgsqlDataReader reader)
        {
            AnimalDTO animal = new AnimalDTO
            {
                Date = reader.GetDateTime(0), 
                Name = reader.GetString(1), 
                Location = reader.GetString(2), 
                Family = reader.GetString(3), 
                Species = reader.GetString(4), 
                Weight = reader.GetDouble(5) 
            };

            return animal;
        }
    }
}

