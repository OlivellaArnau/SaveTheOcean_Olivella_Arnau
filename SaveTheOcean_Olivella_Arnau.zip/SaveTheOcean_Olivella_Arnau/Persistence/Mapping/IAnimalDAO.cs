﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SaveTheOcean_Olivella_Arnau.Persistence.Utils;
using SaveTheOcean_Olivella_Arnau.DTO;
using Npgsql;

namespace SaveTheOcean_Olivella_Arnau.Persistence.Mapping
{
    public interface IAnimalDAO
    {
        AnimalDTO GetAnimalById(int id);
        IEnumerable<AnimalDTO> GetAnimals();
        void AddAnimal(AnimalDTO animal);
    }
}
