﻿using Npgsql;
using SaveTheOcean_Olivella_Arnau.DTO;
using SaveTheOcean_Olivella_Arnau.Persistence.Mapping;
using SaveTheOcean_Olivella_Arnau.Persistence.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SaveTheOcean_Olivella_Arnau.Persistence.DAO
{
    public class AnimalDAO : IAnimalDAO
    {
        private readonly string connectionString;
        public AnimalDAO(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public AnimalDTO GetAnimalById(int id)
        {
            AnimalDTO animal = null;

            using (NpgsqlConnection connection = new NpgsqlConnection(NpgsqlUtils.OpenConnection()))
            {
                string query = "SELECT \"Id\", \"Name\", \"Location\", \"Family\", \"Species\", " +
                               "\"Weight\" " +
                               "FROM \"Animal\" WHERE \"Id\" = @id";
                NpgsqlCommand command = new NpgsqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", id);
                connection.Open();
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    animal = NpgsqlUtils.GetAnimal(reader);
                }
            }

            return animal;
        }
        public void AddAnimal(AnimalDTO animal)
        {
            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
                {
                    string query = "INSERT INTO Animal (Date, Name, Location, Family, Species, Weight) " +
                        "VALUES (@Date, @Name, @Location, @Family, @Species, @Weight)";
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Date", animal.Date);
                        command.Parameters.AddWithValue("@Name", animal.Name);
                        command.Parameters.AddWithValue("@Location", animal.Location);
                        command.Parameters.AddWithValue("@Family", animal.Family);
                        command.Parameters.AddWithValue("@Species", animal.Species);
                        command.Parameters.AddWithValue("@Weight", animal.Weight);

                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while adding the animal: " + ex.Message);
                throw;
            }
        }
        public IEnumerable<AnimalDTO> GetAnimals()
        {
            List<AnimalDTO> animals = new List<AnimalDTO>();

            using (NpgsqlConnection connection = new NpgsqlConnection(NpgsqlUtils.OpenConnection()))
            {
                string query = "SELECT \"Date\", \"Name\", \"Location\", \"Family\", \"Species\", \"Weight\" " +
                "FROM \"Animal\"";
                NpgsqlCommand command = new NpgsqlCommand(query, connection);
                connection.Open();
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    AnimalDTO animal = NpgsqlUtils.GetAnimal(reader);
                    animals.Add(animal);
                }
            }
            return animals;
        }
    }
}
