namespace SaveTheOcean_Olivella_Arnau
{
    public partial class FirstMenu : Form
    {
        public FirstMenu()
        {
            InitializeComponent();
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnJugar_Click(object sender, EventArgs e)
        {
            this.Hide();
            SecondMenu game = new SecondMenu();
            game.ShowDialog();
            this.Close();
        }
    }
}
