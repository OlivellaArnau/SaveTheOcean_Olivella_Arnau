﻿namespace SaveTheOcean_Olivella_Arnau
{
    partial class AddAnimalMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblSaveOcean = new Label();
            label1 = new Label();
            BtnAddAnimalToBD = new Button();
            txtBoxName = new TextBox();
            lblName = new Label();
            lblLocation = new Label();
            txtBoxLocation = new TextBox();
            txtBoxFamily = new TextBox();
            lblFamily = new Label();
            txtBoxSpecies = new TextBox();
            lblSpecies = new Label();
            txtBoxWeight = new TextBox();
            lblWeight = new Label();
            SuspendLayout();
            // 
            // lblSaveOcean
            // 
            lblSaveOcean.AutoSize = true;
            lblSaveOcean.Font = new Font("Showcard Gothic", 30F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblSaveOcean.ForeColor = Color.CadetBlue;
            lblSaveOcean.Location = new Point(150, 28);
            lblSaveOcean.Name = "lblSaveOcean";
            lblSaveOcean.Size = new Size(349, 50);
            lblSaveOcean.TabIndex = 2;
            lblSaveOcean.Text = "Save The Ocean";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 3;
            label1.Text = "label1";
            // 
            // BtnAddAnimalToBD
            // 
            BtnAddAnimalToBD.Font = new Font("Showcard Gothic", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BtnAddAnimalToBD.Location = new Point(425, 223);
            BtnAddAnimalToBD.Name = "BtnAddAnimalToBD";
            BtnAddAnimalToBD.Size = new Size(130, 30);
            BtnAddAnimalToBD.TabIndex = 4;
            BtnAddAnimalToBD.Text = "Añadir Animal";
            BtnAddAnimalToBD.UseVisualStyleBackColor = true;
            BtnAddAnimalToBD.Click += BtnAddAnimal_Click;
            // 
            // txtBoxName
            // 
            txtBoxName.Location = new Point(150, 111);
            txtBoxName.Name = "txtBoxName";
            txtBoxName.Size = new Size(100, 23);
            txtBoxName.TabIndex = 5;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(29, 114);
            lblName.Name = "lblName";
            lblName.Size = new Size(39, 15);
            lblName.TabIndex = 6;
            lblName.Text = "Name";
            lblName.Click += label2_Click;
            // 
            // lblLocation
            // 
            lblLocation.AutoSize = true;
            lblLocation.Location = new Point(29, 169);
            lblLocation.Name = "lblLocation";
            lblLocation.Size = new Size(53, 15);
            lblLocation.TabIndex = 7;
            lblLocation.Text = "Location";
            // 
            // txtBoxLocation
            // 
            txtBoxLocation.Location = new Point(150, 166);
            txtBoxLocation.Name = "txtBoxLocation";
            txtBoxLocation.Size = new Size(100, 23);
            txtBoxLocation.TabIndex = 8;
            // 
            // txtBoxFamily
            // 
            txtBoxFamily.Location = new Point(150, 223);
            txtBoxFamily.Name = "txtBoxFamily";
            txtBoxFamily.Size = new Size(100, 23);
            txtBoxFamily.TabIndex = 10;
            // 
            // lblFamily
            // 
            lblFamily.AutoSize = true;
            lblFamily.Location = new Point(29, 226);
            lblFamily.Name = "lblFamily";
            lblFamily.Size = new Size(42, 15);
            lblFamily.TabIndex = 9;
            lblFamily.Text = "Family";
            lblFamily.Click += label2_Click_1;
            // 
            // txtBoxSpecies
            // 
            txtBoxSpecies.Location = new Point(455, 111);
            txtBoxSpecies.Name = "txtBoxSpecies";
            txtBoxSpecies.Size = new Size(100, 23);
            txtBoxSpecies.TabIndex = 12;
            // 
            // lblSpecies
            // 
            lblSpecies.AutoSize = true;
            lblSpecies.Location = new Point(334, 114);
            lblSpecies.Name = "lblSpecies";
            lblSpecies.Size = new Size(46, 15);
            lblSpecies.TabIndex = 11;
            lblSpecies.Text = "Species";
            // 
            // txtBoxWeight
            // 
            txtBoxWeight.Location = new Point(455, 166);
            txtBoxWeight.Name = "txtBoxWeight";
            txtBoxWeight.Size = new Size(100, 23);
            txtBoxWeight.TabIndex = 14;
            // 
            // lblWeight
            // 
            lblWeight.AutoSize = true;
            lblWeight.Location = new Point(334, 169);
            lblWeight.Name = "lblWeight";
            lblWeight.Size = new Size(45, 15);
            lblWeight.TabIndex = 13;
            lblWeight.Text = "Weight";
            lblWeight.Click += label4_Click;
            // 
            // AddAnimalMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(626, 287);
            Controls.Add(txtBoxWeight);
            Controls.Add(lblWeight);
            Controls.Add(txtBoxSpecies);
            Controls.Add(lblSpecies);
            Controls.Add(txtBoxFamily);
            Controls.Add(lblFamily);
            Controls.Add(txtBoxLocation);
            Controls.Add(lblLocation);
            Controls.Add(lblName);
            Controls.Add(txtBoxName);
            Controls.Add(BtnAddAnimalToBD);
            Controls.Add(label1);
            Controls.Add(lblSaveOcean);
            Name = "AddAnimalMenu";
            Text = "AddAnimalMenu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblSaveOcean;
        private Label label1;
        private Button BtnAddAnimalToBD;
        private TextBox txtBoxName;
        private Label lblName;
        private Label lblLocation;
        private TextBox txtBoxLocation;
        private TextBox txtBoxFamily;
        private Label lblFamily;
        private TextBox txtBoxSpecies;
        private Label lblSpecies;
        private TextBox txtBoxWeight;
        private Label lblWeight;
    }
}