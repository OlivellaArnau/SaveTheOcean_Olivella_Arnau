﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SaveTheOcean_Olivella_Arnau.DTO
{
    public class PlayerDTO
    {
        public string Name { get; set; }
        public string Profesion { get; set; }
        public int XP { get; set; }
    }
}
