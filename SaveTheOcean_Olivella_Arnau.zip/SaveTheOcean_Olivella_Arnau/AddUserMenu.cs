﻿using SaveTheOcean_Olivella_Arnau.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using SaveTheOcean_Olivella_Arnau.Persistence.Utils;
using SaveTheOcean_Olivella_Arnau.Persistence.Mapping;
using Npgsql;
using SaveTheOcean_Olivella_Arnau.DTO;

namespace SaveTheOcean_Olivella_Arnau
{
    public partial class AddUserMenu : Form
    {
        public AddUserMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string profesion = cBoxProfesion.Text;
            string name = txtBoxName.Text;
            int xp = 0;
            if (profesion == "Veterinario")
            {
                xp = 80;
            }
            else if (name == "Tecnico")
            {
                xp = 45;
            }
            PlayerDTO player = new PlayerDTO
            {
                Name = name,
                Profesion = profesion,
                XP = xp
            };
            XMLHelper.CreateXMLFile(player, "Player.xml");
            string export = player.Name;
            RescueMenu rescueMenu = new RescueMenu(export);
            rescueMenu.ShowDialog();
            this.Hide();
        }
    }
}
